'use strict';

/**
 * 抖店后台登录模块
 * - 检查已有登录状态（storageState）
 * - 无登录状态时打开浏览器等待手动扫码
 * - 登录成功后保存 cookie / storageState
 * - 操作失败时截图保存到 logs/screenshots
 */

const { chromium } = require('playwright');
const path = require('path');
const fs = require('fs');

const DOUDIAN_URL = 'https://fxg.jinritemai.com';
const STORAGE_STATE_PATH = process.env.BROWSER_STATE_PATH || '/data/browser/storageState.json';
const SCREENSHOT_DIR = process.env.SCREENSHOT_DIR || '/logs/screenshots';

// 确保截图目录存在
if (!fs.existsSync(SCREENSHOT_DIR)) {
  fs.mkdirSync(SCREENSHOT_DIR, { recursive: true });
}

/**
 * 检查 storageState 是否存在且有效
 */
function hasValidStorageState() {
  if (!fs.existsSync(STORAGE_STATE_PATH)) return false;
  try {
    const data = JSON.parse(fs.readFileSync(STORAGE_STATE_PATH, 'utf-8'));
    // 简单检查：cookies 数组非空
    return Array.isArray(data.cookies) && data.cookies.length > 0;
  } catch {
    return false;
  }
}

/**
 * 截图并保存
 */
async function saveScreenshot(page, name) {
  const filename = `${name}_${Date.now()}.png`;
  const filepath = path.join(SCREENSHOT_DIR, filename);
  try {
    await page.screenshot({ path: filepath, fullPage: true });
    console.log(`[Playwright] 截图已保存: ${filepath}`);
  } catch (e) {
    console.error(`[Playwright] 截图失败: ${e.message}`);
  }
}

/**
 * 启动浏览器，复用或创建登录状态
 * @returns {{ browser, context, page }} 浏览器实例
 */
async function launchWithState(headless = true) {
  const hasState = hasValidStorageState();
  console.log(`[Playwright] 存储状态: ${hasState ? '有效，自动复用' : '无效，需要重新登录'}`);

  const launchOptions = {
    headless,
    args: ['--no-sandbox', '--disable-setuid-sandbox'],
  };

  const browser = await chromium.launch(launchOptions);

  const contextOptions = {
    viewport: { width: 1280, height: 900 },
    userAgent:
      'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
  };

  if (hasState) {
    contextOptions.storageState = STORAGE_STATE_PATH;
  }

  const context = await browser.newContext(contextOptions);
  const page = await context.newPage();

  return { browser, context, page, hasState };
}

/**
 * 检查当前页面是否已登录抖店
 */
async function isLoggedIn(page) {
  try {
    await page.goto(DOUDIAN_URL, { waitUntil: 'domcontentloaded', timeout: 30000 });
    const url = page.url();
    console.log(`[Playwright] 当前 URL: ${url}`);

    // 如果被重定向到登录页，说明未登录
    if (url.includes('login') || url.includes('passport')) {
      return false;
    }

    // 检查页面元素（根据实际页面调整）
    await page.waitForTimeout(2000);
    return true;
  } catch (e) {
    console.error(`[Playwright] 检查登录状态失败: ${e.message}`);
    return false;
  }
}

/**
 * 保存登录状态到文件
 */
async function saveLoginState(context) {
  try {
    const dir = path.dirname(STORAGE_STATE_PATH);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
    await context.storageState({ path: STORAGE_STATE_PATH });
    console.log(`[Playwright] 登录状态已保存: ${STORAGE_STATE_PATH}`);
  } catch (e) {
    console.error(`[Playwright] 保存登录状态失败: ${e.message}`);
  }
}

/**
 * 主入口 - 检查并确保登录状态
 * @param {boolean} interactive 是否允许交互（弹出浏览器窗口）
 */
async function ensureLoggedIn(interactive = false) {
  const { browser, context, page, hasState } = await launchWithState(!interactive);

  try {
    const loggedIn = await isLoggedIn(page);

    if (loggedIn) {
      console.log('[Playwright] ✅ 已登录，登录状态有效');
      await saveLoginState(context);
      return { browser, context, page, status: 'logged_in' };
    }

    if (!interactive) {
      console.log('[Playwright] ❌ 未登录，需要交互模式重新登录');
      await saveScreenshot(page, 'login_required');
      await browser.close();
      return { browser: null, context: null, page: null, status: 'need_login' };
    }

    // 交互模式：等待用户扫码登录
    console.log('[Playwright] 请在浏览器中扫码登录抖店...');
    console.log('[Playwright] 等待登录完成（最多 120 秒）...');

    await page.goto(DOUDIAN_URL, { waitUntil: 'domcontentloaded', timeout: 30000 });

    // 等待跳转到非登录页面
    await page.waitForFunction(
      () => !window.location.href.includes('login') && !window.location.href.includes('passport'),
      { timeout: 120000 }
    );

    console.log('[Playwright] ✅ 登录成功！');
    await saveLoginState(context);
    await saveScreenshot(page, 'login_success');

    return { browser, context, page, status: 'login_success' };
  } catch (e) {
    console.error(`[Playwright] 操作失败: ${e.message}`);
    await saveScreenshot(page, 'error');
    await browser.close();
    return { browser: null, context: null, page: null, status: 'error', error: e.message };
  }
}

// 直接运行此脚本时，执行登录检查
if (require.main === module) {
  const interactive = process.argv.includes('--interactive');
  console.log(`[Playwright] 启动登录检查，交互模式: ${interactive}`);

  ensureLoggedIn(interactive)
    .then(async ({ browser, status }) => {
      console.log(`[Playwright] 最终状态: ${status}`);
      if (browser) await browser.close();
      process.exit(status === 'error' ? 1 : 0);
    })
    .catch((e) => {
      console.error('[Playwright] 致命错误:', e);
      process.exit(1);
    });
}

module.exports = { ensureLoggedIn, isLoggedIn, saveLoginState, launchWithState };
