'use strict';

require('dotenv').config({ path: '../../.env' });

const express = require('express');
const axios = require('axios');
const xml2js = require('xml2js');
const crypto = require('crypto');

const app = express();
const PORT = process.env.WECOM_ADAPTER_PORT || 3001;

// OpenClaw 或 Mock 地址
const OPENCLAW_URL = process.env.OPENCLAW_URL || 'http://openclaw:18789';
const USE_MOCK = process.env.USE_MOCK === 'true' || false;

// 企业微信配置
const WECOM_TOKEN = process.env.WECOM_TOKEN || 'your_wecom_token';
const WECOM_ENCODING_AES_KEY = process.env.WECOM_ENCODING_AES_KEY || '';
const WECOM_CORP_ID = process.env.WECOM_CORP_ID || '';

// ─── 支持的命令关键词 ────────────────────────────────────────────────
const COMMANDS = {
  '今日订单': 'query_today_orders',
  '今日gmv': 'query_today_gmv',
  '今日GMV': 'query_today_gmv',
  '生成日报': 'generate_daily_report',
  '检查抖店登录': 'check_doudian_login',
};

app.use(express.raw({ type: 'text/xml' }));
app.use(express.text({ type: 'text/xml' }));
app.use(express.json());

// ─── 企业微信回调验证 (GET) ─────────────────────────────────────────
app.get('/wecom/callback', (req, res) => {
  const { msg_signature, timestamp, nonce, echostr } = req.query;
  console.log('[WeCom] GET 验证请求', { msg_signature, timestamp, nonce });

  if (!echostr) {
    return res.status(400).send('Missing echostr');
  }

  // 简单验证（生产环境需要完整加解密）
  const token = WECOM_TOKEN;
  const arr = [token, timestamp, nonce, echostr].sort();
  const sha1 = crypto.createHash('sha1').update(arr.join('')).digest('hex');

  if (sha1 === msg_signature) {
    console.log('[WeCom] 验证通过');
    return res.send(echostr);
  }

  // 如果 AES 加密模式，需解密 echostr
  console.log('[WeCom] 签名验证失败，直接返回 echostr（开发模式）');
  return res.send(echostr);
});

// ─── 接收企业微信消息 (POST) ────────────────────────────────────────
app.post('/wecom/callback', async (req, res) => {
  const rawBody = req.body?.toString() || '';
  console.log('[WeCom] 收到消息:', rawBody.substring(0, 200));

  let msgObj = {};
  try {
    const parsed = await xml2js.parseStringPromise(rawBody, { explicitArray: false });
    msgObj = parsed?.xml || {};
  } catch (e) {
    console.error('[WeCom] XML 解析失败:', e.message);
    return res.send('<xml><result>fail</result></xml>');
  }

  const msgType = msgObj.MsgType;
  const content = (msgObj.Content || '').trim();
  const fromUser = msgObj.FromUserName;
  const toUser = msgObj.ToUserName;

  console.log('[WeCom] 消息内容:', { msgType, content, fromUser });

  // 只处理文本消息
  if (msgType !== 'text') {
    return res.send(buildTextReply(toUser, fromUser, '目前只支持文本消息 😊'));
  }

  // 命令路由
  const command = matchCommand(content);
  let replyText = '';

  if (command) {
    try {
      replyText = await dispatch(command, content, fromUser);
    } catch (e) {
      console.error('[WeCom] 指令处理失败:', e.message);
      replyText = `❌ 处理失败：${e.message}`;
    }
  } else {
    // 未知命令 - 显示帮助
    replyText = buildHelpText();
  }

  return res.send(buildTextReply(toUser, fromUser, replyText));
});

// ─── 命令匹配 ───────────────────────────────────────────────────────
function matchCommand(content) {
  for (const [keyword, cmd] of Object.entries(COMMANDS)) {
    if (content.includes(keyword)) return cmd;
  }
  return null;
}

// ─── 命令分发 ───────────────────────────────────────────────────────
async function dispatch(command, content, fromUser) {
  if (USE_MOCK) {
    return await mockHandler(command);
  }

  // 转发给 OpenClaw
  try {
    const response = await axios.post(
      `${OPENCLAW_URL}/v1/chat/completions`,
      {
        model: 'gpt-4',
        messages: [
          {
            role: 'system',
            content: '你是抖店运营助手，用简洁中文回复。',
          },
          {
            role: 'user',
            content: content,
          },
        ],
        stream: false,
      },
      { timeout: 30000 }
    );

    return response.data?.choices?.[0]?.message?.content || '无返回内容';
  } catch (e) {
    console.error('[WeCom] OpenClaw 请求失败，降级到 Mock:', e.message);
    return await mockHandler(command);
  }
}

// ─── Mock 处理器 ────────────────────────────────────────────────────
async function mockHandler(command) {
  const today = new Date().toLocaleDateString('zh-CN');

  switch (command) {
    case 'query_today_orders':
      return `📦 今日订单（Mock）\n日期：${today}\n订单数：128\n已付款：115\n待发货：13`;

    case 'query_today_gmv':
      return `💰 今日GMV（Mock）\n日期：${today}\nGMV：¥ 23,456\n较昨日：+12.3%`;

    case 'generate_daily_report':
      return generateMockReport();

    case 'check_doudian_login':
      return `🔐 抖店登录状态检查（Mock）\n状态：已登录\n账号：mock@shop.com\n上次检查：${new Date().toLocaleTimeString('zh-CN')}`;

    default:
      return '未知命令';
  }
}

// ─── 生成 Mock 日报 ─────────────────────────────────────────────────
function generateMockReport() {
  const today = new Date().toLocaleDateString('zh-CN');
  return `【抖店日报】
日期：${today}
GMV：¥ 23,456
订单数：128
退款数：5
待发货：13
核心建议：
1. 爆款商品库存告急，建议今日补货
2. 退款率较昨日上升，关注品控
3. 下午3-5点流量高峰，可考虑加大投流`;
}

// ─── 构建企业微信文本回复 ────────────────────────────────────────────
function buildTextReply(fromUser, toUser, content) {
  const timestamp = Math.floor(Date.now() / 1000);
  return `<xml>
<ToUserName><![CDATA[${toUser}]]></ToUserName>
<FromUserName><![CDATA[${fromUser}]]></FromUserName>
<CreateTime>${timestamp}</CreateTime>
<MsgType><![CDATA[text]]></MsgType>
<Content><![CDATA[${content}]]></Content>
</xml>`;
}

// ─── 帮助文本 ───────────────────────────────────────────────────────
function buildHelpText() {
  return `🤖 抖店 AI 助手

支持以下命令：
• 今日订单 - 查看今日订单概况
• 今日GMV - 查看今日 GMV
• 生成日报 - 生成今日运营日报
• 检查抖店登录 - 检查 Playwright 登录状态

发送关键词即可触发 ✨`;
}

// ─── 健康检查 ───────────────────────────────────────────────────────
app.get('/health', (req, res) => {
  res.json({ status: 'ok', service: 'wecom-adapter', time: new Date().toISOString() });
});

app.listen(PORT, () => {
  console.log(`[WeCom Adapter] 启动成功，端口: ${PORT}`);
  console.log(`[WeCom Adapter] Mock 模式: ${USE_MOCK}`);
  console.log(`[WeCom Adapter] OpenClaw URL: ${OPENCLAW_URL}`);
});
